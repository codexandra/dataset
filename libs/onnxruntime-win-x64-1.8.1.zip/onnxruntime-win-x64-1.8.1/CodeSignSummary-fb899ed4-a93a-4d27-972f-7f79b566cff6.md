 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | onnxruntime.dll           | Pass   | 6.57MB   | 83.65          | 1.24        | 0.3         | 81.99         | 0           | 
 | time_providers_shared.dll | Pass   | 10.5KB   | 63.15          | 0.62        | 0.41        | 61.49         | 0           | 
