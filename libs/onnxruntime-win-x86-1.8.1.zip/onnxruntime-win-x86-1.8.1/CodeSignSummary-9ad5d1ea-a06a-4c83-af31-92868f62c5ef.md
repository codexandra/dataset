 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | onnxruntime.dll           | Pass   | 5.65MB   | 53.28          | 1.13        | 0.36        | 51.77         | 0           | 
 | time_providers_shared.dll | Pass   | 8.5KB    | 114.85         | 0.65        | 0.37        | 113.34        | 0           | 
