#pragma once

#include "c10/util/Flags.h"
#include "caffe2/core/common.h"
