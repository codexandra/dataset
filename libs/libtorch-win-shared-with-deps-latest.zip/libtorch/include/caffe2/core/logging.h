#pragma once
#include "c10/util/Logging.h"
#include "caffe2/core/common.h"
