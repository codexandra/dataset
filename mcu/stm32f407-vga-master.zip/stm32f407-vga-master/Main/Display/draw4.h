#ifndef DRAW4_H
#define DRAW4_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void Draw4(uint8_t* bitmap, uint16_t* colors, uint8_t* dest);

#ifdef __cplusplus
}
#endif

#endif  // DRAW4_H
