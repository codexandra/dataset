#ifndef _ETL_ERROR_IGNORE_H_INCLUDED
#define _ETL_ERROR_IGNORE_H_INCLUDED

#include "etl/error/flow.h"

#define IGNORE(expr) ETL_IGNORE(expr)

#endif  // _ETL_ERROR_IGNORE_H_INCLUDED
