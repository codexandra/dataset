#ifndef _ETL_ERROR_CHECK_H_INCLUDED
#define _ETL_ERROR_CHECK_H_INCLUDED

#include "etl/error/flow.h"

#define CHECK(expr) ETL_CHECK(expr)

#endif  // _ETL_ERROR_CHECK_H_INCLUDED
