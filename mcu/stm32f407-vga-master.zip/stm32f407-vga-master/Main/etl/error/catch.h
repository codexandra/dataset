#ifndef _ETL_ERROR_CATCH_H_INCLUDED
#define _ETL_ERROR_CATCH_H_INCLUDED

#include "etl/error/flow.h"

#define CATCH(expr) ETL_CATCH(expr)

#endif  // _ETL_ERROR_CATCH_H_INCLUDED
