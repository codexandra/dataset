Example of using OV7670 camera with STM32F429.

Data from camera are captured by DCMI and saved to SDRAM.

LTDC is used for generating VGA signal.

Double buffering is used for display an image.