Example of using STM32F429 for generating VGA picture.

LTDC + SDRAM are used.