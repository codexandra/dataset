#ifndef   SETTTINGPROC_H
#define   SETTTINGPROC_H

void  SettingProcess(void);
void  SettingSystick(void);
void  SettingUIInit(void);

#endif
