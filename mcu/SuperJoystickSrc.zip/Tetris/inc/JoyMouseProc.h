#ifndef   JOYMOUSEPROC_H
#define   JOYMOUSEPROC_H

void  JoystickProcess(void);
void  JoystickSystick(void);
void  JoystickUIInit(void);

void  MouseProcess(void);
void  MouseSystick(void);
void  MouseUIInit(void);

void  AirMouseProcess(void);
void  AirMouseSystick(void);
void  AirMouseUIInit(void);
#endif

