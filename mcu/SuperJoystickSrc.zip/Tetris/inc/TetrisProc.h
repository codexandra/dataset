#ifndef   TETRISPROC_H
#define   TETRISPROC_H

void  TetrisProcess(void);
void  TetrisSystick(void);
void  TetrisUIInit(void);

#endif

