This is USB microphone realization for STM32F4-DISCOVERY. 
MEMS microphone installed at the board is used in this project.

Проект USB микрофона для STM32F4-DISCOVERY.

http://we.easyelectronics.ru/STM32/usb-mikrofon-na-baze-stm32f4-discovery.html

See: https://github.com/iliasam/stm32f4-discovery_sound_playback if you need just audio playback.  
