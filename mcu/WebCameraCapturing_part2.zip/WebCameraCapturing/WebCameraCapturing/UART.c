#include "UART.h"

const char arHex[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

void UART_Init(void)
{
	//1.Multiplexing peripheral
	uint32_t ul_UART_pins_mask = PIO_PA8A_URXD | PIO_PA9A_UTXD;
	PIOA->PIO_ABSR &= ~ul_UART_pins_mask;									//Peripheral A selected for both line (0 is A, 1 is B)
	PIOA->PIO_PDR = ul_UART_pins_mask;										//Moves pins control from PIO controller to Peripheral
	
	//2.UART settings (UART is disabled on reset)
	UART->UART_BRGR =84000000/16/115200;									//Clock Divisor value according to datasheet formula
	UART->UART_MR = UART_MR_CHMODE_NORMAL | UART_MR_PAR_NO;					//Normal mode, no parity
	UART->UART_CR = UART_CR_TXEN;											//Enable transmitter
	UART->UART_IDR = 0xFFFFu;												//Disable all interrupts
}

void PrintStr(char *Text)
{
	int i = 0;
	do
	{
		while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}						//wait until previous character is processed
		UART->UART_THR = Text[i];											//send next character
		i++;
	}
	while (Text[i] != 0);													//loop until string termination symbol (null)
}

void PrintHEX(uint8_t* ptrBuffer, uint32_t Length)
{
	uint8_t ByteToSend;
	for (uint32_t i = 0; i < Length; i ++)
	{
		PrintStr("0x");										//Printing prefix
		
		ByteToSend = ptrBuffer[i] >> 4;						//Extracting higher half-byte
		ByteToSend = arHex[ByteToSend];                     //Getting readable char
		while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}		//Waiting until UART is ready
		UART->UART_THR = ByteToSend;						//Sending
		
		ByteToSend = ptrBuffer[i] & 0x0F;					//Extraction lower half-byte
		ByteToSend = arHex[ByteToSend];
		while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
		UART->UART_THR = ByteToSend;
		
		if(i != (Length - 1))
		{
			PrintStr(" ");									//Separating bytes for readability
		}
	}
}

void PrintHEX16(uint16_t Number)
{
	uint8_t SentByte;
	PrintStr("0x");
	
	SentByte = Number >> 12;				
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 8) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 4) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = Number & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
}

void PrintHEX32(uint32_t Number)
{
	uint8_t SentByte;
	PrintStr("0x");
	
	SentByte = Number >> 28;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 24) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 20) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 16) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 12) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 8) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = (Number >> 4) & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
	
	SentByte = Number & 0x000F;
	SentByte = arHex[SentByte];
	while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
	UART->UART_THR = SentByte;
}

void PrintBIN8(uint8_t Number)
{
	uint32_t Result;									//Working variable
	for(int i = 0; i < 8; i ++)							//There are 8 bits in a byte
	{
		Result = (Number << i);							//Getting needed bit into position
		Result = (Result & (1u << 7));					//Extraction it
		
		while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}	//Waiting till UART is ready
		if(Result == 0)									
			UART->UART_THR = '0';						//Sending '0'
		else
			UART->UART_THR = '1';						//Sending '1'
		
		if((i + 1) % 4 == 0)							//Every half-byte is separated
		{												//by white space for better readability
			while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
			UART->UART_THR = ' ';
		}
	}
}

void PrintBIN16(uint16_t Number)
{
	uint32_t Result;
	for(int i = 0; i < 16; i ++)
	{
		Result = (Number << i);
		Result = (Result & (1u << 15));
		
		while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
		if(Result == 0)
			UART->UART_THR = (0 + 48);
		else
			UART->UART_THR = (1 + 48);
		
		if((i + 1) % 4 == 0)
		{
			while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
			UART->UART_THR = ' ';
		}
		
		if((i + 1) % 8 == 0)
		{
			while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
			UART->UART_THR = ' ';
		}
	}
}

void PrintBIN32(uint32_t Number)
{
	uint32_t Result;
	for(int i = 0; i < 32; i ++)
	{
		Result = (Number << i);
		Result = (Result & (1u << 31));
		
		while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
		if(Result == 0)
			UART->UART_THR = (0 + 48);
		else
			UART->UART_THR = (1 + 48);
		
		if((i + 1) % 4 == 0)
		{
			while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
			UART->UART_THR = ' ';
		}
		
		if((i + 1) % 8 == 0)
		{
			while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
			UART->UART_THR = ' ';
		}
	}	
}

void PrintDEC(uint32_t Number)
{
	uint32_t Temp, Divider, Result;
	
	Temp = Number;
	Divider = 10;
	
	while(Temp / Divider)						//Finding the divider		
		Divider = Divider * 10;
	
	Divider = Divider / 10;						//Don't need last one as division by it makes zero
	while(Divider)
	{		
		Result = Temp / Divider;				//Extracting a digit (decimals are discarded)
		Temp = Temp - Result * Divider;			//Decreasing by 1 order of magnitude	
		Divider = Divider / 10;					//Readjusting divider	
		
		while(0 == (UART->UART_SR & UART_SR_TXRDY)) {}
		UART->UART_THR = Result + 48;			//Sending out the digit
	}
}