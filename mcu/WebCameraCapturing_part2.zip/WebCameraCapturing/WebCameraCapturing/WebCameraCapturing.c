#include "sam.h"
#include "UART.h"

uint32_t SysTickCounter;
uint8_t arBuffer[4] = {0x24, 0x01, 0x55, 0x56};

void SysTick_Handler(void)
{
	uint32_t Pin_LEDRX;
	uint32_t Pin_LEDTX;
	
	SysTickCounter ++;
	if(1000 == SysTickCounter)
	{
		SysTickCounter = 0;
		
		Pin_LEDRX = 1 << (PIO_PC30_IDX & 0x1Fu);
		Pin_LEDTX = 1 << (PIO_PA21_IDX & 0x1Fu);
		if(PIOC->PIO_PDSR & Pin_LEDRX)
		{
			PIOC->PIO_CODR = Pin_LEDRX;	//Lights on
			PIOA->PIO_CODR = Pin_LEDTX;
		}
		else
		{
			PIOC->PIO_SODR = Pin_LEDRX;	//Lights off
			PIOA->PIO_SODR = Pin_LEDTX;
		}
		
		PrintStr("Hello World\r\n");
	}
}

int main(void)
{
	SystemInit();
	UART_Init();
	
	PrintStr("\r\n");
	PrintStr("Testing PrintDEC function: \r\n");
	PrintDEC(0);
	PrintStr(" ");
	PrintDEC(3);
	PrintStr(" ");
	PrintDEC(25);
	PrintStr(" ");
	PrintDEC(128);
	PrintStr(" ");
	PrintDEC(250);
	PrintStr(" ");
	PrintDEC(1285);
	PrintStr(" ");
	PrintDEC(25001);
	PrintStr(" ");
	PrintDEC(560022);
	PrintStr(" ");
	PrintDEC(1000234);
	PrintStr("\r\n\r\n");
	
	PrintStr("Testing PrintBIN functions: \r\n");
	PrintBIN8(0b00110011);
	PrintStr("\r\n");
	PrintBIN16(0b0011010101010101);
	PrintStr("\r\n");
	PrintBIN32(0x55555555);
	PrintStr("\r\n\r\n");
	
	PrintStr("Testing PrintHEX functions: \r\n");
	PrintHEX(arBuffer, 4);
	PrintStr("\r\n");
	PrintHEX16(0x1);
	PrintStr(" ");
	PrintHEX16(0x1202);
	PrintStr(" ");
	PrintHEX32(0x1);
	PrintStr(" ");
	PrintHEX32(0x11989865);
	PrintStr(" ");
	PrintHEX32(0x2450);
	PrintStr(" ");
	PrintHEX32(0x256450);
	
	while(1);
}
