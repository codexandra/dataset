#include "sam.h"

uint32_t SysTickCounter;

void SysTick_Handler(void)
{	
	uint32_t Pin_LEDRX;
	uint32_t Pin_LEDTX;
	
	SysTickCounter ++;
	if(1000 == SysTickCounter)
	{
		SysTickCounter = 0;
		
		Pin_LEDRX = 1 << (PIO_PC30_IDX & 0x1Fu);
		Pin_LEDTX = 1 << (PIO_PA21_IDX & 0x1Fu);
		if(PIOC->PIO_PDSR & Pin_LEDRX)
		{
			PIOC->PIO_CODR = Pin_LEDRX;	//Lights on								
			PIOA->PIO_CODR = Pin_LEDTX;
		}
		else
		{
			PIOC->PIO_SODR = Pin_LEDRX;	//Lights off								
			PIOA->PIO_SODR = Pin_LEDTX;
		}
	}
}

int main(void)
{
    SystemInit();
    while(1);
}
