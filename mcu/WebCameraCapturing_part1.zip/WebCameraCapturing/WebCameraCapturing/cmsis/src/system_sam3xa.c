#include "sam3xa.h"

#ifdef __cplusplus
extern "C" {
	#endif

	/* Clock settings (84MHz) */
	#define SYS_BOARD_OSCOUNT   (CKGR_MOR_MOSCXTST(0x8))
	#define SYS_BOARD_PLLAR     (CKGR_PLLAR_ONE | CKGR_PLLAR_MULA(0xdUL) | CKGR_PLLAR_PLLACOUNT(0x3fUL) | CKGR_PLLAR_DIVA(0x1UL))

	void SystemInit( void )
	{
		/* Set FWS according to SYS_BOARD_MCKR configuration */
		EFC0->EEFC_FMR = EEFC_FMR_FWS(4);
		EFC1->EEFC_FMR = EEFC_FMR_FWS(4);

		/* Initialize main oscillator */
		PMC->CKGR_MOR |= CKGR_MOR_KEY_PASSWD | SYS_BOARD_OSCOUNT | CKGR_MOR_MOSCXTEN;
		while ( !(PMC->PMC_SR & PMC_SR_MOSCXTS) );

		/* Switch to 3-20MHz Xtal oscillator */
		PMC->CKGR_MOR |= CKGR_MOR_KEY_PASSWD | CKGR_MOR_MOSCSEL;
		while ( !(PMC->PMC_SR & PMC_SR_MOSCSELS) );

		/* Initialize PLLA */
		PMC->CKGR_PLLAR = SYS_BOARD_PLLAR;
		while ( !(PMC->PMC_SR & PMC_SR_LOCKA) );
		
		/* Setting up prescaler */
		PMC->PMC_MCKR = PMC_MCKR_PRES_CLK_2 | PMC_MCKR_CSS_MAIN_CLK;
		while ( !(PMC->PMC_SR & PMC_SR_MCKRDY) ) ;

		/* Switch to PLLA */
		PMC->PMC_MCKR = PMC_MCKR_PRES_CLK_2 | PMC_MCKR_CSS_PLLA_CLK;	
		while ( !(PMC->PMC_SR & PMC_SR_MCKRDY) ) ;
			
		/* Activates clock to PIO controllers */
		PMC->PMC_PCER0 =(1u << ID_PIOA) | (1u << ID_PIOB) | (1u << ID_PIOC) | (1u << ID_PIOD);
		
		/* RX LED pin initialization (output, default high)*/
		uint32_t Pin = 1u << (PIO_PC30_IDX & 0x1F);	//Moving 1 to position 30
		PIOC->PIO_IDR = Pin;						//No interrupt
		PIOC->PIO_PUDR = Pin;						//No pull-up
		PIOC->PIO_MDDR = Pin;						//No open collector
		PIOC->PIO_CODR = Pin;						//Low level
		PIOC->PIO_OER = Pin;						//Output
		PIOC->PIO_PER = Pin;						//Enables
		
		/* TX Pin pin initialization (output, default high) */
		Pin = 1u << (PIO_PA21_IDX & 0x1F);
		PIOA->PIO_IDR = Pin;
		PIOA->PIO_PUDR = Pin;
		PIOA->PIO_MDDR = Pin;
		PIOA->PIO_CODR = Pin;
		PIOA->PIO_OER = Pin;
		PIOA->PIO_PER = Pin;
		
		/* Initialization of SysTick */
		/* Reload value is every 1ms. -1 is for 1 tick to reload value */
		SysTick->LOAD = ((84000000/1000) & SysTick_LOAD_RELOAD_Msk) - 1;
		/* Clear current value */	
		SysTick->VAL = 0;														
		/* Source is not divided by 8, enables SysTick, enables interrupt */
		SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_TICKINT_Msk;	
	}

	#ifdef __cplusplus
}
#endif