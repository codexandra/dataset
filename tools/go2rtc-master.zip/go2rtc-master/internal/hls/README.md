## Useful links

- https://walterebert.com/playground/video/hls/
