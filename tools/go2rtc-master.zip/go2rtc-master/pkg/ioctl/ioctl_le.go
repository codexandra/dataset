//go:build mipsle

package ioctl

const (
	read  = 1
	write = 2
)
