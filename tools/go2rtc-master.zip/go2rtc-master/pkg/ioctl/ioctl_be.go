//go:build arm || arm64 || 386 || amd64

package ioctl

const (
	write = 1
	read  = 2
)
