# IOCTL

This is just an example how Linux IOCTL constants works.
