## Useful links

- https://www.kurento.org/blog/rtp-i-intro-rtp-and-sdp