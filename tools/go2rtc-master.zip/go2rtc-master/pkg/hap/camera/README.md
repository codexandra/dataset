## Useful links

- https://github.com/bauer-andreas/secure-video-specification
