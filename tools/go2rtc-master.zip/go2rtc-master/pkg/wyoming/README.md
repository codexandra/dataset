##  Default wake words

- alexa_v0.1
- hey_jarvis_v0.1
- hey_mycroft_v0.1
- hey_rhasspy_v0.1
- ok_nabu_v0.1

## Useful Links

- https://github.com/rhasspy/wyoming-satellite
- https://github.com/rhasspy/wyoming-openwakeword
- https://github.com/fwartner/home-assistant-wakewords-collection
- https://github.com/esphome/micro-wake-word-models/tree/main?tab=readme-ov-file
