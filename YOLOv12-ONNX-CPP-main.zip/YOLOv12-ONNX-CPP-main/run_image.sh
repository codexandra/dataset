cd build/ && ./image_inference
