cd build/ && ./camera_inference
