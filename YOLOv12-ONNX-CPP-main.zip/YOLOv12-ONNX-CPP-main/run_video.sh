cd build/ && ./video_inference
